<?php
include dirname(__FILE__) . "/../Header.php";
include dirname(__FILE__) . "/HeaderMenu.php";
include dirname(__FILE__) . "/MainCol.php";
include dirname(__FILE__) . "/../Footer.php";
?>