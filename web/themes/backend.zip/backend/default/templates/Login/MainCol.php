<div class="container">
	<div class="row" style="margin: 50px 0;">
		<div class="col-md-4"></div>
		
		<div class="col-md-4">
			<div class="panel panel-default">
				<div class="panel-heading">
	    			<h1 class="panel-title"><?php echo $this->title ?></h1>
	    		</div>
			
	    		<div class="panel-body">
	    			<?= $content ?>
	    		</div>
			</div>
		</div>
		
		<div class="col-md-4"></div>
    </div>	       
</div>