</div><!-- wrap -->
<footer class="footer">
    <div class="container">
        <p class="text-center">&copy; vaishyvivahbandhan.com <?= date('Y') ?></p>
    </div>
</footer>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
